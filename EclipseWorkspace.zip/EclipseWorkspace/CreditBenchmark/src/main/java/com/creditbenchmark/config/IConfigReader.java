package com.creditbenchmark.config;

public interface IConfigReader {
	
	public String getWebsite();
	
	public String getUserName();
	
	public String getPassword();
}
