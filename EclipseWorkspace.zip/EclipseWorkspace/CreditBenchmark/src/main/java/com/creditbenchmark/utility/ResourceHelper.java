package com.creditbenchmark.utility;

public class ResourceHelper {
	
	public static String getPath(String resource) {
		String path = getBasePath() + resource;
		return path;
	}
	
	private static String getBasePath() {
		String path = System.getProperty("user.dir");
		return path;
	}
}
