package com.creditbenchmark.config;

import java.io.InputStream;
import java.util.Properties;

public class ConfigReader implements IConfigReader {
	
	private Properties props = null;

	public ConfigReader() {
		
		props=new Properties();
		
		try {
			InputStream configStream = ConfigReader.class.getResourceAsStream("/configs/config.properties");
			props.load(configStream);
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
	}

	public String getWebsite() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getUserName() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getPassword() {
		// TODO Auto-generated method stub
		return null;
	}

}
