package com.creditbenchmark.setup;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import com.creditbenchmark.config.Config;
import com.creditbenchmark.config.ConfigReader;

import cucumber.api.java.After;
import cucumber.api.java.Before;

import com.creditbenchmark.browsers.*;;

public class SetupTest {

	public static WebDriver driver;

	@Before()
	public void before() throws Exception {

		Config.settings = new ConfigReader();
		setupDriver();
	}
	
	@After
	public void tearDown() throws InterruptedException {
		driver.manage().deleteAllCookies();
		driver.quit();
		driver = null;
	}

	public void setupDriver() throws Exception {
		driver= getDriver("CHROME");
		driver.manage().timeouts().pageLoadTimeout(240, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	private WebDriver getDriver(String bType) throws Exception {

		switch (bType) {

		case "CHROME": {
			Chrome chrome = new Chrome();
			return chrome.getDriver();
		}

		}
		return null;
	}
}
