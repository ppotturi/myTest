package com.creditbenchmark.browsers;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.creditbenchmark.utility.ResourceHelper;

public class Chrome {
	
	public WebDriver getDriver() {
		System.setProperty("webdriver.chrome.driver", ResourceHelper.getPath("/src/main/resources/drivers/chromedriver.exe"));
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		driver.manage().timeouts().setScriptTimeout(60, TimeUnit.SECONDS);
		return driver;
	}
}
