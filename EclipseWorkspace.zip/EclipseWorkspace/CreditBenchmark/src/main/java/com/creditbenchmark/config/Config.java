package com.creditbenchmark.config;

public class Config {
	public static IConfigReader settings;
}
