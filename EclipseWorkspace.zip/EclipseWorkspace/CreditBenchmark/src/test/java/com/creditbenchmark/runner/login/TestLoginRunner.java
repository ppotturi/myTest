package com.creditbenchmark.runner.login;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features= {"src/test/resources/features/login/Login.feature"}, 
glue= {"com.creditbenchmark.setup","com.creditbenchmark.step_definitions"})
public class TestLoginRunner extends AbstractTestNGCucumberTests {

}
